import axios from 'axios';

const PAYSTACK_BASE_URL = 'https://api.paystack.co';

const getSecretKey = () => process.env.PAYSTACK_SECRET_KEY;

const headers = () => ({ Authorization: `Bearer ${getSecretKey()}`, 'Content-Type': 'application/json' });

export const initializePayment = async (amount, email, reference) => {
  const secretKey = getSecretKey();
  if (!secretKey) throw new Error('Paystack secret key not configured');
  const response = await axios.post(`${PAYSTACK_BASE_URL}/transaction/initialize`, { amount: Math.round(Number(amount) * 100), email, reference }, { headers: headers() });
  return response.data;
};

export const verifyPayment = async reference => {
  if (!getSecretKey()) throw new Error('Paystack secret key not configured');
  const response = await axios.get(`${PAYSTACK_BASE_URL}/transaction/verify/${encodeURIComponent(reference)}`, { headers: headers() });
  return response.data;
};

export const createTransferRecipient = async (accountNumber, bankCode, name, type = 'nuban') => {
  if (!getSecretKey()) throw new Error('Paystack secret key not configured');
  const response = await axios.post(`${PAYSTACK_BASE_URL}/transferrecipient`, { type, name, account_number: accountNumber, bank_code: bankCode }, { headers: headers() });
  return response.data;
};

export const initiateTransfer = async (amount, recipientCode, reason) => {
  if (!getSecretKey()) throw new Error('Paystack secret key not configured');
  const response = await axios.post(`${PAYSTACK_BASE_URL}/transfer`, { source: 'balance', amount: Math.round(Number(amount) * 100), recipient: recipientCode, reason }, { headers: headers() });
  return response.data;
};
