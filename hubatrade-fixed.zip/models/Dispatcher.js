import mongoose from 'mongoose';

const dispatcherSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true, index: true },
  companyName: { type: String, required: true, trim: true },
  fleetSize: { type: Number, default: 1, min: 1 },
  baseRate: { type: Number, required: true, min: 0 },
  perKmRate: { type: Number, required: true, min: 0 },
  isVerified: { type: Boolean, default: false },
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

export default mongoose.models.Dispatcher || mongoose.model('Dispatcher', dispatcherSchema);
