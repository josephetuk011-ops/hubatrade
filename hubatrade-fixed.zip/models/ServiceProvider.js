import mongoose from 'mongoose';

const serviceProviderSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true, index: true },
  businessName: { type: String, required: true, trim: true },
  serviceType: { type: String, required: true, trim: true, index: true },
  hourlyRate: { type: Number, required: true, min: 0 },
  workingHours: { type: mongoose.Schema.Types.Mixed, default: {} },
  availability: { type: Boolean, default: true },
  isVerified: { type: Boolean, default: false },
  rating: { type: Number, default: 0, min: 0, max: 5 }
}, { timestamps: true });

export default mongoose.models.ServiceProvider || mongoose.model('ServiceProvider', serviceProviderSchema);
