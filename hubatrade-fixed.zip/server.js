import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 5000;

if (!process.env.DATABASE_URL) {
  console.error('❌ DATABASE_URL environment variable is not set');
  process.exit(1);
}
if (!process.env.JWT_SECRET) {
  console.error('❌ JWT_SECRET environment variable is not set');
  process.exit(1);
}

app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_URL ? process.env.CLIENT_URL.split(',').map(v => v.trim()) : true, credentials: true }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 200, standardHeaders: true, legacyHeaders: false }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

let dbConnected = false;
let dbPromise = null;

const connectDatabase = async () => {
  if (dbPromise) return dbPromise;
  dbPromise = mongoose.connect(process.env.DATABASE_URL, {
    connectTimeoutMS: 10000,
    serverSelectionTimeoutMS: 10000,
    retryWrites: true,
    w: 'majority'
  }).then(() => {
    dbConnected = true;
    console.log('✅ MongoDB Connected Successfully');
  }).catch(err => {
    dbPromise = null;
    dbConnected = false;
    console.error('❌ MongoDB Connection Error:', err.message);
  });
  return dbPromise;
};

connectDatabase();
mongoose.connection.on('connected', () => { dbConnected = true; });
mongoose.connection.on('disconnected', () => { dbConnected = false; console.warn('⚠️ MongoDB disconnected'); });
mongoose.connection.on('error', err => console.error('❌ MongoDB error:', err.message));

app.get('/api/health', (req, res) => {
  res.status(dbConnected ? 200 : 503).json({
    status: dbConnected ? 'healthy' : 'degraded',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    database: dbConnected ? 'connected' : 'disconnected',
    paystack: process.env.PAYSTACK_SECRET_KEY ? 'configured' : 'not_configured'
  });
});

import authRoutes from './routes/auth.js';
import productRoutes from './routes/products.js';
import orderRoutes from './routes/orders.js';
import paymentRoutes from './routes/payment.js';
import vendorRoutes from './routes/vendors.js';
import providerRoutes from './routes/providers.js';
import cartRoutes from './routes/cart.js';
import categoryRoutes from './routes/categories.js';
import dispatcherRoutes from './routes/dispatcher.js';
import reviewRoutes from './routes/reviews.js';
import searchRoutes from './routes/search.js';
import wishlistRoutes from './routes/wishlist.js';

app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/vendors', vendorRoutes);
app.use('/api/providers', providerRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/dispatchers', dispatcherRoutes);
app.use('/api/reviews', reviewRoutes);
app.use('/api/search', searchRoutes);
app.use('/api/wishlist', wishlistRoutes);

app.get('/', (req, res) => res.json({ message: 'Welcome to Hubatrade API', version: '1.0.0', health: '/api/health' }));

app.use((err, req, res, next) => {
  console.error('❌ Error:', err.stack || err.message);
  res.status(err.status || 500).json({ success: false, message: err.message || 'Internal Server Error' });
});

app.use((req, res) => res.status(404).json({ success: false, message: 'Route not found', path: req.originalUrl }));

const server = app.listen(PORT, () => {
  console.log(`🚀 Hubatrade Server running on port ${PORT}`);
  console.log(`🌐 Environment: ${process.env.NODE_ENV || 'production'}`);
  console.log(`📊 Paystack: ${process.env.PAYSTACK_SECRET_KEY ? 'Active' : 'Not configured'}`);
});

const shutdown = async signal => {
  console.log(`⛔ ${signal} received. Shutting down...`);
  server.close(async () => {
    try { await mongoose.connection.close(); } catch (e) { console.error(e.message); }
    process.exit(0);
  });
};
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

export default app;
